from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

ROUTER_URL = "http://localhost:5050/query"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send', methods=['POST'])
def send():
    query = request.json.get("query", "")
    try:
        res = requests.post(ROUTER_URL, json={"query": query})
        return jsonify(res.json())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=8080)